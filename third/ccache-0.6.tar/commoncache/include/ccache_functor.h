/********************************************************************
	created:	2008/01/23
	filename: 	functor.h
	author:		Lichuang
                
	purpose:    
*********************************************************************/

#ifndef __CCACHE_FUNCTOR_H__
#define __CCACHE_FUNCTOR_H__

#include "ccache.h"

int ccache_init_functor(ccache_functor_t *functor);

#endif /* __CCACHE_FUNCTOR_H__ */

