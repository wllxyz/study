/********************************************************************
	created:	2008/01/23
	filename: 	list.h
	author:		Lichuang
                
	purpose:    
*********************************************************************/

#ifndef __CCACHE_LIST_H__
#define __CCACHE_LIST_H__

int ccache_init_list_functor(ccache_functor_t *functor);

#endif /* __CCACHE_LIST_H__ */

