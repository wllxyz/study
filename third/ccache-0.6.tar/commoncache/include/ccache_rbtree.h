/********************************************************************
	created:	2008/10/06
	filename: 	rbtree.h
	author:		Lichuang
                
	purpose:    
*********************************************************************/

#ifndef __CCACHE_RBTREE_H__
#define __CCACHE_RBTREE_H__

int ccache_init_rbtree_functor(ccache_functor_t *functor);

#endif /* __CCACHE_RBTREE_H__ */

