/********************************************************************
	created:	2009/10/05
	filename: 	ccache_util.h
	author:		Lichuang
                
	purpose:    
*********************************************************************/

#ifndef __CCACHE_UTIL_H__
#define __CCACHE_UTIL_H__

void ccache_string_trim(char *buffer);
int  ccache_ispowerof2(int value);

#endif /* __CCACHE_UTIL_H__ */

