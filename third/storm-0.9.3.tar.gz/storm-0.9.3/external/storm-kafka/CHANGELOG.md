## 0.9.2-incubating (0.5.0)
* incorporated as an Apache Storm external module
* fixed partition assignment for KafkaSpout
* upgraded to storm 0.9.1

## 0.4.0
* added support for reading kafka message keys
* configurable metrics emit interval

## 0.3.0
* updated partition path in zookeeper
* added error handling for fetch request

